
Please rename GeoMatch_exe to GeoMatch.exe

Please rename run_bat to run.bat

Please download following opencv Dll files and copy to this folder.

	cxcore200.dll
	cv200.dll
	highgui200.dll

execute run bat